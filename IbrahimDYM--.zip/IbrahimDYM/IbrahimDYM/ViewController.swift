//
//  ViewController.swift
//  IbrahimDYM
//
//  Created by user213711 on 10/27/22.
//
import AVFoundation
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnplaybutton: UIButton!
    @IBOutlet weak var lbldatetitle: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblReservation: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var lblDateName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var imgDateImage: UIImageView!
    var DateObjects = [Date]()
    
    var player: AVAudioPlayer?
    
    var seguePasssedObject = Date()
    
    
    func InitializeDates() {
        let d1 = Date()
        d1.DateName = "Cook With Your Boo"
        d1.DateDescription = "Even if you're not much of a cook, trying out a new dish can result in lots of laughs. Not to mention, you get to eat the results"
        d1.DatePrice = "$50.00"
        d1.DateReservation = "No"
        d1.DateDuration = "Varies"
        d1.DateLocation = "At home"
        d1.DateImage = "cooking.jpeg"
        d1.DateLink = "https://www.youtube.com/watch?v=mhDJNfV7hjk"
        DateObjects.append(d1)
        
        
        let d2 = Date()
        d2.DateName = "Movie Drive-in"
        d2.DateDescription = "Many drive-ins still play double features, so you get twice the films for your buck. Besides, it's delightfully retro."
        d2.DatePrice = "$65.00"
        d2.DateReservation = "Yes"
        d2.DateDuration = "varies"
        d2.DateLocation = "Based on location"
        d2.DateImage = "drivein.jpeg"
        d2.DateLink = "https://www.youtube.com/watch?v=F_L-ejnCOhk"
        DateObjects.append(d2)
        
        let d3 = Date()
        d3.DateName = "Put together a puzzle"
        d3.DateDescription = "Ther's something so satisfying about finally clicking that last piece into place, plus it's good for the ol'noodle. "
        d3.DatePrice = "$15.00"
        d3.DateReservation = "No"
        d3.DateDuration = "Varies"
        d3.DateLocation = "At home"
        d3.DateImage = "puzzle.jpeg"
        d3.DateLink = "https://www.youtube.com/watch?v=DioH1eV7pHQ"
        DateObjects.append(d3)
        
        let d4 = Date()
        d4.DateName = "In door sky-diving"
        d4.DateDescription = "Discover indoor skydiving and experience the same rush as tandem skydiving! Skydiving is all about the freefall – and indoor skydiving gives you that pure adrenaline rush for the entire length of the experience."
        d4.DatePrice = "$200.00"
        d4.DateReservation = "Yes"
        d4.DateDuration = "1 hour"
        d4.DateLocation = "Based on location"
        d4.DateImage = "skydiving.jpeg"
        d4.DateLink = "https://www.youtube.com/watch?v=2rgc8PPoWqo"
        DateObjects.append(d4)
        
        let d5 = Date()
        d5.DateName = "Take a hike"
        d5.DateDescription = "Something about exploring nature with your main squeeze really gets the heart going in other way, if you know what we mean."
        d5.DatePrice = "FREE"
        d5.DateReservation = "No"
        d5.DateDuration = "Varies"
        d5.DateLocation = "Nearby Trails"
        d5.DateImage = "hike2.jpeg"
        d5.DateLink = "https://www.youtube.com/watch?v=AElc6netzQ4"
        DateObjects.append(d5)
        
        let d6 = Date()
        d6.DateName = "Have a spa night"
        d6.DateDescription = "Hit up the drugstore for face masks, mani-pedi suppplies and massage oil for a DIY pampering sesh that will improve your bond and your skin."
        d6.DatePrice = "$30.00"
        d6.DateReservation = "No"
        d6.DateDuration = "1 hour"
        d6.DateLocation = "At home"
        d6.DateImage = "spa.jpeg"
        d6.DateLink = "https://www.youtube.com/watch?v=-yDkiVRZVSQ"
        DateObjects.append(d6)
        
        
    }
    
    func SetLables() {
        //let randomHT = DateObjects.randomElement()
        let randomHT = seguePasssedObject
        lblDateName.text = randomHT.DateName
        txtDescription.text = randomHT.DateDescription
        lblPrice.text = randomHT.DatePrice
        lblReservation.text = randomHT.DateReservation
        lblDuration.text = randomHT.DateDuration
        lblLocation.text = randomHT.DateLocation
        imgDateImage.image = UIImage(named: randomHT.DateImage)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        InitializeDates()
        
        SetLables()
        
    }
    
    override func becomeFirstResponder() -> Bool {
        return true
    }

    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?){
        if motion == .motionShake {
            print("Shake Gesture Detected")
            SetLables()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var destController = segue.destination as! DetailViewController
        destController.PassedDate = seguePasssedObject
    }
    
    @IBAction func tchNextDate(_ sender: Any) {
        SetLables()
    }
    
    @IBAction func tchPauseButton(_ sender: Any) {
        if let player = player, player.isPlaying {
            //stop playback
            btnplaybutton.setTitle("Stop", for: .normal)
            player.stop()
            
        }
        else {
            //set up player
            btnplaybutton.setTitle("Play", for: .normal)
            let urlString = Bundle.main.path(forResource: "sound", ofType: "mp3")
            do {
                try AVAudioSession.sharedInstance().setMode(.default)
                try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
                guard let urlString = urlString else {
                    return
                }
                player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath:urlString))
                guard let player = player else {
                    return
                }
                player.play()
            }
            catch {
                print("something went wrong")
            }
        }
    }
}

