//
//  Date.swift
//  IbrahimDYM
//
//  Created by user213711 on 10/27/22.
//

import Foundation
import UIKit
class Date {
    var DateName = ""
    var DateDescription = ""
    var DateCategory = ""
    var DateImage = ""
    var DatePrice = ""
    var DateReservation = ""
    var DateDuration = ""
    var DateLocation = ""
    var DateLink = ""
}
