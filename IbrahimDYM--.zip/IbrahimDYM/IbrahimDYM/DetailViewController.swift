//
//  DetailViewController.swift
//  IbrahimDYM
//
//  Created by user213711 on 12/12/22.
//

import Foundation
import UIKit
import WebKit
class DetailViewController: UIViewController {
    
    @IBOutlet weak var wkBrowser: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let siteURL = URL(string: PassedDate.DateLink)
        let request = URLRequest(url:siteURL!)
        wkBrowser.load(request)
    }
    
    var PassedDate = Date()
}
