//
//  MasterListController.swift
//  IbrahimDYM
//
//  Created by user213711 on 12/12/22.
//

import Foundation
import UIKit
class MasterListController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //GetJSONData()
        InitializeDates()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  DateObjects.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let rowNum = indexPath.row
        
        let dt = DateObjects[rowNum]
        
        let cellA = tableView.dequeueReusableCell(withIdentifier: "cellA")
        
        cellA?.textLabel!.text = "RANDOM DATE"
        let downloadedImage = convertToimage(urlString: "https://raw.githubusercontent.com/SagaIbrahim/IT315Ibrahim/main/randomdate.png")
        cellA?.imageView?.image = downloadedImage
        cellA?.imageView?.image = downloadedImage
        cellA?.imageView?.contentMode = UIView.ContentMode.scaleAspectFill
        // Set the size of the Imageview Frame
        cellA?.imageView?.frame.size.width = 200
        cellA?.imageView?.frame.size.height = 200
        // Make Image Corners Rounded
        cellA?.imageView?.layer.cornerRadius = 5
        cellA?.imageView?.clipsToBounds = true
        cellA?.imageView?.layer.borderWidth = 2
        cellA?.imageView?.layer.borderColor = UIColor.white.cgColor
        cellA?.detailTextLabel!.text = dt.DateLocation
        return cellA!
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "showDetail"){
            let selectedRowIndex = tableView.indexPathForSelectedRow!.row
            var selectedDT = DateObjects[selectedRowIndex]
            
            let destinationController = segue.destination as! ViewController
            destinationController.seguePasssedObject = selectedDT
        }
    }
    
    func convertToimage(urlString: String) -> UIImage {
        
        let imgURL = URL(string:urlString)!
        
        let imgData  = try? Data(contentsOf: imgURL)
        print(imgData ?? "Error. Image does not exist at URL \(imgURL)")
        
        let img = UIImage(data: imgData!)
    
        return img!
    }
    
    var DateObjects = [Date]()
    
    /**func GetJSONData() {
        let endPointString = "https://raw.githubusercontent.com/SagaIbrahim/IT315Ibrahim/main/dateideas2.json"
        
        let endPointURL = URL(string: endPointString)
        
        let dataBytes = try? Data(contentsOf:endPointURL!)
        print(dataBytes)
        
        if (dataBytes != nil) {
            let dictionary:NSDictionary = (try! JSONSerialization.jsonObject(with: dataBytes!, options: JSONSerialization.ReadingOptions.mutableContainers)) as! NSDictionary
            
            print("Dictionary --:  \(dictionary) ---- \n") // for debugging purposes
           
            
            let dtDictionary = dictionary["Dates"]! as! [[String:AnyObject]]
            
            
            for index in 0...dtDictionary.count - 1  {
                let singleDT = dtDictionary[index]
                let dt = Date()
                //reterive each object from the dictionary
                dt.DateName = singleDT["DateName"] as! String
                print("DateName: - \(dt.DateName)")
                dt.DateDescription = singleDT["DateDescription"] as! String
                dt.DatePrice = singleDT["DatePrice"] as! String
                dt.DateImage = singleDT["DateImage"] as! String
                dt.DateLink = singleDT["DateLink"] as! String
                dt.DateLocation = singleDT["DateLocation"] as! String
                dt.DateReservation = singleDT["DateReservation"] as! String
                dt.DateDuration = singleDT["DateDuration"] as!String
                DateObjects.append(dt)
            }
            
        }**/
    
     func InitializeDates() {
        let d1 = Date()
        d1.DateName = "Cook With Your Boo"
        d1.DateDescription = "Even if you're not much of a cook, trying out a new dish can result in lots of laughs. Not to mention, you get to eat the results"
        d1.DatePrice = "$50.00"
        d1.DateReservation = "No"
        d1.DateDuration = "Varies"
        d1.DateLocation = "At home"
        d1.DateImage = "cooking.jpeg"
        d1.DateLink = "https://www.youtube.com/watch?v=mhDJNfV7hjk"
        DateObjects.append(d1)
        
        
        let d2 = Date()
        d2.DateName = "Movie Drive-in"
        d2.DateDescription = "Many drive-ins still play double features, so you get twice the films for your buck. Besides, it's delightfully retro."
        d2.DatePrice = "$65.00"
        d2.DateReservation = "Yes"
        d2.DateDuration = "varies"
        d2.DateLocation = "Based on location"
        d2.DateImage = "drivein.jpeg"
        d2.DateLink = "https://www.youtube.com/watch?v=F_L-ejnCOhk"
        DateObjects.append(d2)
        
        let d3 = Date()
        d3.DateName = "Put together a puzzle"
        d3.DateDescription = "Ther's something so satisfying about finally clicking that last piece into place, plus it's good for the ol'noodle. "
        d3.DatePrice = "$15.00"
        d3.DateReservation = "No"
        d3.DateDuration = "Varies"
        d3.DateLocation = "At home"
        d3.DateImage = "puzzle.jpeg"
        d3.DateLink = "https://www.youtube.com/watch?v=DioH1eV7pHQ"
        DateObjects.append(d3)
        
        let d4 = Date()
        d4.DateName = "In door sky-diving"
        d4.DateDescription = "Discover indoor skydiving and experience the same rush as tandem skydiving! Skydiving is all about the freefall – and indoor skydiving gives you that pure adrenaline rush for the entire length of the experience."
        d4.DatePrice = "$200.00"
        d4.DateReservation = "Yes"
        d4.DateDuration = "1 hour"
        d4.DateLocation = "Based on location"
        d4.DateImage = "skydiving.jpeg"
        d4.DateLink = "https://www.youtube.com/watch?v=2rgc8PPoWqo"
        DateObjects.append(d4)
        
        let d5 = Date()
        d5.DateName = "Take a hike"
        d5.DateDescription = "Something about exploring nature with your main squeeze really gets the heart going in other way, if you know what we mean."
        d5.DatePrice = "FREE"
        d5.DateReservation = "No"
        d5.DateDuration = "Varies"
        d5.DateLocation = "Nearby Trails"
        d5.DateImage = "hike2.jpeg"
        d5.DateLink = "https://www.youtube.com/watch?v=AElc6netzQ4"
        DateObjects.append(d5)
        
        let d6 = Date()
        d6.DateName = "Have a spa night"
        d6.DateDescription = "Hit up the drugstore for face masks, mani-pedi suppplies and massage oil for a DIY pampering sesh that will improve your bond and your skin."
        d6.DatePrice = "$30.00"
        d6.DateReservation = "No"
        d6.DateDuration = "1 hour"
        d6.DateLocation = "At home"
        d6.DateImage = "spa.jpeg"
        d6.DateLink = "https://www.youtube.com/watch?v=-yDkiVRZVSQ"
        DateObjects.append(d6)
        
        
    }
    
}
