//
//  ViewController.swift
//  DateYourMate
//
//  Created by user213711 on 10/25/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Photo: UIImageView!
    
    var dateType = ["Outdoors", "Indoors", "Activities", "Creative", "Unsual", "Dinner"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.Photo.image = UIImage(named: "date101.jpeg")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

