//
//  Date.swift
//  DateYourMate
//
//  Created by user213711 on 10/25/22.
//

import Foundation
import UIKit
class Date {
    var DateCategory = ""
    var DateName = ""
    var DateDescription = ""
    var DateCost = ""
    var DateTime = ""
}
